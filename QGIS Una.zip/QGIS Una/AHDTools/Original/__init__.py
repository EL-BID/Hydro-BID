# -*- coding: utf-8 -*-
"""
/***************************************************************************
 AHDTools
                                 A QGIS plugin
 Constructs a menu for AHD options
                             -------------------
        begin                : 2015-05-12
        copyright            : (C) 2015 by Mark Bruhn/RTI International
        email                : mbruhn@rti.org
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""


# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    """Load AHDTools class from file AHDTools.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    #
    from .ahdtools import AHDTools
    return AHDTools(iface)
