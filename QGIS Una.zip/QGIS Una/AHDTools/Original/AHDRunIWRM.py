"""
/***************************************************************************
 AHD Navigator - is a subclass of AHD Navigator Base without any changes (I think)

                             -------------------
        begin                : 2012-01-10
        copyright            : (C) 2012 by RTI International for Interamerican Development Bank
        email                : jbisese@rti.org
 ***************************************************************************/
"""
import datetime
import ConfigParser
import os.path
from subprocess import call,Popen

from AHDRunIWRM_ui import Ui_AHDRunIWRM
from AHDNavigatorBase import AHDNavigatorBase, AHDNavigatorBaseDialog
from ahdUtils import DefaultDict

# Import the PyQt and QGIS libraries
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *

from PyQt4 import QtCore, QtGui
from qgis import core

# create the AHD Run IRWM Dialog.   This is called by the AHDTools during the __init__

class AHDRunIWRMDialog(AHDNavigatorBaseDialog):

    def __init__(self, AHDTools): # , debug_flag):

        QtGui.QDialog.__init__(self)

        # Set up the user interface from Designer.
        self.ui = Ui_AHDRunIWRM()
        self.ui.setupUi(self)

        self.debug_flag = False

        self.iface = AHDTools.iface

        return


class AHDRunIWRM(AHDNavigatorBase):

    def __init__(self, dlg, config):

        self.dlg = dlg

        self.iface = self.dlg.iface

        # counter to show that dialog has already started running
        self.config = config
        self.am_active = False
        # Save reference to the QGIS interface
        # reference to map canvas
        self.canvas = self.iface.mapCanvas()
        # reference to map tool
        self.saveTool = self.canvas.mapTool()
        # our click tool will emit a QgsPoint on every click.  This does not allow modifiers
        self.pointEmitter = self.NoModifierPointEmitter(self.canvas)
        # counter for stuff
        self.i = 0
        # create a list to hold our selected feature ids
        self.selectList = []
        # current layer ref (set in handleLayerChange)
        self.ahd_geo_layer = None
        # this is the table that will be used for navigation
        self.ahd_flow_table_layer = None
        # spatial index for AHD geometry layer
        self.ahd_geo_layer_index = None
        # this is the AHD Navigation object.
        self.AhdNav = None
        # direction of navigation
        self.navigation_direction = "upstream"

        self.config = config
        # set these from the values in the CONFIG file.
        self.idColName(self.config.get('ahdtools', 'idcol_name'))
        self.fromColName(self.config.get('ahdtools', 'fromcol_name'))
        self.toColName(self.config.get('ahdtools', 'tocol_name'))

        nav_layers = self.setGeoLayers(self.dlg.ui.geo_layer_combo_box)
        flow_tables = self.setFlowTables(self.dlg.ui.flow_table_combo_box)
        QObject.connect(QgsMapLayerRegistry.instance(), SIGNAL("layerWillBeRemoved(QString)"), self.handleLayerRemove)

        # connect the layer changed handler to a signal that the TOC layer has changed
        QObject.connect(self.iface, SIGNAL("currentLayerChanged(QgsMapLayer *)"), self.handleCurrentLayerChanged)

        # connect the Reset and Close buttons to button_clicked()
        QObject.connect(self.dlg.ui.buttonBox, SIGNAL('clicked(QAbstractButton *)'),self.uiButtonBox_clicked)

        QObject.connect(QgsMapLayerRegistry.instance(), SIGNAL("layerWasAdded(QgsMapLayer *)"), self.handleLayerAdd)

        QObject.connect(self.dlg.ui.geo_layer_combo_box,SIGNAL("currentIndexChanged(int)"),self.comboChange)
        QObject.connect(self.dlg.ui.flow_table_combo_box,SIGNAL("currentIndexChanged(int)"),self.comboChange)

        QObject.connect(self.dlg.ui.chkActivate,SIGNAL("stateChanged(int)"),self.toggle_activate)

        QObject.connect(self.dlg.ui.pushButton, SIGNAL("clicked()"), self.RunIWRM_clicked)

        # connect to mouse click with modifiers (Shift and Control) signal
        QObject.connect(self.pointEmitter, SIGNAL( "canvasClickedWithModifiers" ), self.handleMouseDown)
        QObject.connect(self.pointEmitter, SIGNAL( "canvasClickedWithModifiers" ), self.selectFeature)

        self.run()


    def RunIWRM_clicked(self):

        self.dlg.appendTextBrowser("debug", "RunIWRM_clicked(self, button)")
        if self.dlg.ui.chkActivate.isChecked() == False or self.AhdNav == None:
            QMessageBox.information( self.iface.mainWindow(),"Info", "To run the IWRM from QGis you need to have an AHDFlow layer and a AHD geometry layer loaded, and have already navigated upstream." )
            self.dlg.raise_()
            return
        if self.AhdNav.COMID_NAVIGATED == 0:
            QMessageBox.information( self.iface.mainWindow(),"Info", "To run the IWRM from QGis you have already navigated upstream on a catchment or flowline." )
            self.dlg.raise_()
            return

        ahd_section_nm = 'ahd_navigation_results'

        self.dlg.appendTextBrowser("debug", "Run IWRM with COMID==" + str(self.AhdNav.COMID_NAVIGATED))
        config_parser = self.config
        if config_parser == None :
            QMessageBox.information( self.iface.mainWindow(),"Info",
            "self.config == None. hould be in the plugin folder '" + str(os.path.dirname(__file__)) + "'." )
            return
        if config_parser.has_section('iwrmqgis') == False:
            self.dlg.appendTextBrowser("debug", "config_parser.has_section('ahdtools')==" + str(config_parser.has_section('ahdtools')))
            QMessageBox.information( self.iface.mainWindow(),"Info",
            "A config.ini file is required to run the RunIWRM menu.  It should be in the plugin folder '" + str(os.path.dirname(__file__)) + "'." )
            return
        # re-read the config file but just for the 'iwrmsettings' which can be changed while QGis is running
        iwrmsettings = ConfigParser.ConfigParser()
        here = os.path.join(os.path.dirname(__file__),"config.ini")
        iwrmsettings.read(here)

        try:
            output_path = config_parser.get('iwrmqgis', 'output_path')
            jar_path = config_parser.get('iwrmqgis', 'jar_path')
            jar_file = config_parser.get('iwrmqgis', 'jar_file')
            setting_file_basename = config_parser.get('iwrmqgis', 'setting_file_basename')
            java_path = config_parser.get('iwrmqgis', 'java_path')

            config_parser.set('iwrmsettings', 'catchment', str(self.AhdNav.COMID_NAVIGATED))
            iwrmsettings.set('iwrmsettings','catchment', str(self.AhdNav.COMID_NAVIGATED))
            config_parser.set('iwrmsettings', 'runname', 'IWRM.' + str(self.AhdNav.COMID_NAVIGATED))
            iwrmsettings.set('iwrmsettings', 'runname', config_parser.get('iwrmsettings', 'runname'))
            config_parser.set('iwrmqgis', 'command', java_path  + ' -jar ' + jar_path + jar_file + ' -f ' +  output_path + setting_file_basename + "." + str(self.AhdNav.COMID_NAVIGATED) + ".txt")
        except:
            raise

        # write the AHD Navigator results to a config formatted file.
        nav_file = os.path.join(output_path, setting_file_basename + '.'  + str(self.AhdNav.COMID_NAVIGATED) + '.' + 'nav_results' + '.' + 'txt')
        try:
            f = open(nav_file, 'w')
            for section in config_parser._sections:
                if section != 'iwrmsettings':
                    f.write("[" + str(section) + "]\n")
                    for (key, value) in config_parser._sections[section].items():
                        if key != '__name__':
                            f.write( str(key) + "=" + str(value) + "\n")
            f.close()
            nav_file = None
            f = None
            section_nm = 'ahd_navigation_results'
            config_parser.remove_section(section_nm)
        except:
            raise
            pass

        # write the config file 'settings.{COMID}.txt' which will be used to run the model
        config_file = os.path.join(output_path, setting_file_basename + '.' + str(self.AhdNav.COMID_NAVIGATED) + '.txt')
        try:
            f = open(config_file, 'w')
            for section in iwrmsettings._sections:
                if section == 'iwrmsettings':
                    #f.write("[" + str(section) + "]\n")
                    for (key, value) in iwrmsettings._sections[section].items():
                        if key != '__name__':
                            f.write( str(key) + "=" + str(value) + "\n")
            f.close()
            config_file = None
            f = None
        except:
            config_file = None
            raise

        """
            This is where the IWRM command is executed
        """
        try:
            import string
            command_tx = config_parser.get('iwrmqgis', 'command')
            commands = command_tx.split(' ')
            self.dlg.appendTextBrowser("debug", "IWRM command_tx==" + command_tx)

            pid = Popen(commands).pid
        except:
            QMessageBox.information( self.iface.mainWindow(),"ERROR", "Error running IWRM.  command_tx==" + command_tx )
            pass

    """
        Run IWRM doesn't allow fancy selects using Shift or Control, so ignore any key modifier
    """
    class NoModifierPointEmitter(QgsMapToolEmitPoint):

        def __init__(self, canvas):
        	QgsMapToolEmitPoint.__init__(self, canvas)
        	self.canvas = canvas

        def canvasPressEvent(self, mouseEvent):
        	point = self.toMapCoordinates( mouseEvent.pos() )

        	self.emit( SIGNAL( "canvasClickedWithModifiers" ), point, mouseEvent.button(), Qt.NoModifier )
