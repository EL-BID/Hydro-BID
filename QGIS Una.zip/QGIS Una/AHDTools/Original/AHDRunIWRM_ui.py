# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'AHDRunIWRM_ui.ui'
#
# Created: Tue Jan 31 10:15:10 2012
#      by: PyQt4 UI code generator 4.8.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_AHDRunIWRM(object):
    def setupUi(self, AHDRunIWRM):
        AHDRunIWRM.setObjectName(_fromUtf8("AHDRunIWRM"))
        AHDRunIWRM.setWindowModality(QtCore.Qt.NonModal)
        AHDRunIWRM.resize(400, 315)
        AHDRunIWRM.setWindowTitle(QtGui.QApplication.translate("AHDRunIWRM", "RTI AHD Run IWRM Model", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonBox = QtGui.QDialogButtonBox(AHDRunIWRM)
        self.buttonBox.setGeometry(QtCore.QRect(240, 270, 131, 25))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Close|QtGui.QDialogButtonBox.Reset)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.txtFeedback = QtGui.QTextBrowser(AHDRunIWRM)
        self.txtFeedback.setGeometry(QtCore.QRect(10, 10, 381, 181))
        self.txtFeedback.setObjectName(_fromUtf8("txtFeedback"))
        self.chkActivate = QtGui.QCheckBox(AHDRunIWRM)
        self.chkActivate.setGeometry(QtCore.QRect(10, 260, 91, 31))
        self.chkActivate.setText(QtGui.QApplication.translate("AHDRunIWRM", "Activate\n"
"(check)", None, QtGui.QApplication.UnicodeUTF8))
        self.chkActivate.setObjectName(_fromUtf8("chkActivate"))
        self.geo_layer_combo_box = QtGui.QComboBox(AHDRunIWRM)
        self.geo_layer_combo_box.setGeometry(QtCore.QRect(103, 200, 261, 22))
        self.geo_layer_combo_box.setToolTip(QtGui.QApplication.translate("AHDRunIWRM", "Select AHD Catchment or Stream Layer", None, QtGui.QApplication.UnicodeUTF8))
        self.geo_layer_combo_box.setObjectName(_fromUtf8("geo_layer_combo_box"))
        self.label = QtGui.QLabel(AHDRunIWRM)
        self.label.setGeometry(QtCore.QRect(10, 200, 91, 21))
        self.label.setText(QtGui.QApplication.translate("AHDRunIWRM", "Geometry Layer", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setObjectName(_fromUtf8("label"))
        self.flow_table_combo_box = QtGui.QComboBox(AHDRunIWRM)
        self.flow_table_combo_box.setGeometry(QtCore.QRect(104, 226, 261, 22))
        self.flow_table_combo_box.setToolTip(QtGui.QApplication.translate("AHDRunIWRM", "Select AHD Catchment or Stream Layer", None, QtGui.QApplication.UnicodeUTF8))
        self.flow_table_combo_box.setObjectName(_fromUtf8("flow_table_combo_box"))
        self.label_2 = QtGui.QLabel(AHDRunIWRM)
        self.label_2.setGeometry(QtCore.QRect(11, 226, 91, 21))
        self.label_2.setText(QtGui.QApplication.translate("AHDRunIWRM", "AHD Flow table", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.pushButton = QtGui.QPushButton(AHDRunIWRM)
        self.pushButton.setGeometry(QtCore.QRect(100, 270, 77, 25))
        self.pushButton.setText(QtGui.QApplication.translate("AHDRunIWRM", "Run IWRM", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))

        self.retranslateUi(AHDRunIWRM)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), AHDRunIWRM.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), AHDRunIWRM.reject)
        QtCore.QMetaObject.connectSlotsByName(AHDRunIWRM)

    def retranslateUi(self, AHDRunIWRM):
        pass

