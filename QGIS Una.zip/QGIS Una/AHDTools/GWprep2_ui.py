# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'GWprep2_ui.ui'
#
# Created: Tue Jun 09 15:35:07 2015
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_GWprep(object):
    def setupUi(self, GWprep):
        GWprep.setObjectName(_fromUtf8("GWprep"))
        GWprep.setWindowModality(QtCore.Qt.NonModal)
        GWprep.resize(600, 425)
        self.buttonBox = QtGui.QDialogButtonBox(GWprep)
        self.buttonBox.setGeometry(QtCore.QRect(405, 265, 131, 100))
        self.buttonBox.setOrientation(QtCore.Qt.Vertical) #Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Ok|QtGui.QDialogButtonBox.Close) #|QtGui.QDialogButtonBox.Reset)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.txtFeedback = QtGui.QTextBrowser(GWprep)
        self.txtFeedback.setGeometry(QtCore.QRect(10, 10, 581, 181))
        self.txtFeedback.setObjectName(_fromUtf8("txtFeedback"))
        self.chkActivate = QtGui.QCheckBox(GWprep)
        #self.chkActivate.setGeometry(QtCore.QRect(10, 600, 91, 31)) #way at bottom of window
        self.chkActivate.setGeometry(QtCore.QRect(10, 600, 1, 1)) #not being used at this time & hidden by making it only 1x1 pixel
        self.chkActivate.setObjectName(_fromUtf8("chkActivate"))
        self.groupBox = QtGui.QGroupBox(GWprep)
        #self.groupBox.setGeometry(QtCore.QRect(80, 305, 200, 75))
        self.groupBox.setGeometry(QtCore.QRect(80, 305, 1, 1))  #not being used at this time & hidden by making it only 1x1 pixel
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.AllRecs_button = QtGui.QRadioButton(self.groupBox)
        self.AllRecs_button.setGeometry(QtCore.QRect(10, 20, 132, 18))
        self.AllRecs_button.setObjectName(_fromUtf8("AllRecs_button"))
        self.OnlyMatchRecs_button = QtGui.QRadioButton(self.groupBox)
        self.OnlyMatchRecs_button.setGeometry(QtCore.QRect(10, 45, 152, 18))
        self.OnlyMatchRecs_button.setObjectName(_fromUtf8("OnlyMatchRecs_button"))
        self.point_layer_combo_box = QtGui.QComboBox(GWprep)
        self.point_layer_combo_box.setGeometry(QtCore.QRect(153, 200, 435, 22))
        self.point_layer_combo_box.setObjectName(_fromUtf8("point_layer_combo_box"))
        self.label = QtGui.QLabel(GWprep)
        self.label.setGeometry(QtCore.QRect(10, 200, 141, 21))
        self.label.setObjectName(_fromUtf8("label"))
        self.poly_layer_combo_box = QtGui.QComboBox(GWprep)
        self.poly_layer_combo_box.setGeometry(QtCore.QRect(190, 236, 400, 22))
        self.poly_layer_combo_box.setObjectName(_fromUtf8("poly_layer_combo_box"))
        self.label_2 = QtGui.QLabel(GWprep)
        self.label_2.setGeometry(QtCore.QRect(11, 236, 181, 21))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.label_3 = QtGui.QLabel(GWprep)
        self.label_3.setGeometry(QtCore.QRect(11, 275, 350, 21))
        self.label_3.setObjectName(_fromUtf8("label_3"))

        self.retranslateUi(GWprep)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), GWprep.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), GWprep.reject)
        QtCore.QMetaObject.connectSlotsByName(GWprep)

    def retranslateUi(self, GWprep):
        GWprep.setWindowTitle(_translate("GWprep", "RTI Analytical Hydrology Dataset Groundwater Data Prep", None))
        self.chkActivate.setText(_translate("GWprep", "Activate\n"
"(check)", None))
        self.groupBox.setTitle(_translate("GWprep", "Output Table", None))
        self.OnlyMatchRecs_button.setText(_translate("GWprep", "Only Matching", None))
        self.AllRecs_button.setText(_translate("GWprep", "All Records Kept", None))
        self.point_layer_combo_box.setToolTip(_translate("GWprep", "Select Groundwater points", None))
        self.label.setText(_translate("GWprep", "GW Points Layer", None))
        self.poly_layer_combo_box.setToolTip(_translate("GWprep", "Select AHD Catchment Layer", None))
        self.label_2.setText(_translate("GWprep", "AHD Catchments Layer", None))
        self.label_3.setText(_translate("GWprep", "<b>Join Catchment Attributes to GW points? ..............................</b>", None))
if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    GWprep = QtGui.QDialog()
    ui = Ui_GWprep()
    ui.setupUi(GWprep)
    GWprep.show()
    sys.exit(app.exec_())

