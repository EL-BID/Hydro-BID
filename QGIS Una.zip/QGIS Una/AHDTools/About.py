"""
/***************************************************************************
 About.  This is overkill for a simple splash window, but it reads the version and contact out of the
 config.ini file.

                             -------------------
        begin                : 2012-01-10
        copyright            : (C) 2012 by RTI International for Interamerican Development Bank
        email                : jbisese@rti.org
 ***************************************************************************/
"""
from PyQt4.QtCore import *
from PyQt4.QtGui import *

from qgis.core import *
from About_ui import Ui_Dialog

class AboutDialog(QDialog, Ui_Dialog):

    def __init__(self, AHDTools):
    	QDialog.__init__(self)

    	self.setupUi(self)

class About:
    def __init__(self, dlg, config):
        self.dlg = dlg

        self.config = config

        if self.config.has_section('general'):
            version = self.config.get('general', 'version')
            self.dlg.label.setText("Version: " + version)
            contact = self.config.get('general', 'contact')
            self.dlg.label_3.setText("Contact: " + contact)
            link = self.config.get('general', 'URL')
            main_tx = self.dlg.textBrowser.toHtml()
            main_tx.replace('http://www.rti.org', link)
            self.dlg.textBrowser.setText(main_tx)

        self.run()

    # run method that performs all the real work
    def run(self):
        try:
            self.dlg.show()
            self.dlg.raise_()

            result = self.dlg.exec_()
        except:
            raise

        ### this is reached when the window is closed using the window close widget in the upper right corner, ###
        ### or after the Close button is pressed ###
        return 1