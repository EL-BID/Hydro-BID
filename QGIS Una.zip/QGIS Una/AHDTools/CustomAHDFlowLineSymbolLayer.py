"""
/***************************************************************************
 AHD Navigator - is a subclass of AHD Navigator Base without any changes (I think)

                             -------------------
        begin                : 2012-01-10
        copyright            : (C) 2012 by RTI International for Interamerican Development Bank
        email                : jbisese@rti.org
 ***************************************************************************/
"""
import ConfigParser
import os.path
# Import the PyQt and QGIS libraries
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *

def colorToString(color):
    try:
        return "%d,%d,%d,%d" % (color.red(),color.green(),color.blue(),color.alpha())
    except:
        return str(color)

class CustomLineSymbolLayer(QgsLineSymbolLayerV2):

  # You shouldn't get lines using these default colors. They are opposite what you'd expect.  They are purposefully ugly, so if you see them something is wrong
  def __init__(self, line_width=1, line_color=QColor(255,0,0,255), line_select_width=2, line_select_color=QColor(0,0,255,255)):

    try:
        color_array = line_color.split(',')
        self.line_color = QColor(int(color_array[0]),int(color_array[1]),int(color_array[2]),int(color_array[3]))
    except:
        self.line_color = line_color

    try:
        color_array = []
        color_array = line_select_color.split(',')
        self.line_select_color = QColor(int(color_array[0]),int(color_array[1]),int(color_array[2]),int(color_array[3]))
    except:
        self.line_select_color = line_select_color

    self.line_width = line_width
    self.line_select_width = line_select_width

    QgsLineSymbolLayerV2.__init__(self)

  def layerType(self):
    return "AHDCustomLine"

  def properties(self):

    try:
        color_array = self.line_color.split(',')
        self.line_color = QColor(int(color_array[0]),int(color_array[1]),int(color_array[2]),int(color_array[3]))
    except:
        pass
    try:
        color_array = self.line_select_color.split(',')
        self.line_select_color = QColor(int(color_array[0]),int(color_array[1]),int(color_array[2]),int(color_array[3]))
    except:
        pass

    return {
            'line_width' : str(self.line_width),
            'line_color' : "%d,%d,%d,%d" % (self.line_color.red(),self.line_color.green(),self.line_color.blue(),self.line_color.alpha()),
            'line_select_width' : str(self.line_select_width),
            'line_select_color' : "%d,%d,%d,%d" % (self.line_select_color.red(),self.line_select_color.green(),self.line_select_color.blue(),self.line_select_color.alpha()),
            }

  def startRender(self, context):
    if self.line_color == None:
        return
    #pass

  def stopRender(self, context):
    pass

  def renderPolyline(self, line, context):

    if line == None:
        return

    if self.line_color == None:
        return

    """
    this crashed when I had multiple layers present, and added 3 tables.   Error was
    in renderPolyline
        qcolor = QColor(self.line_select_color)
    TypeError: 'NoneType' object is not callable
    this try block might help
    """
    try:
        qcolor = QColor(self.line_color)
    except:
        return

    if context.selected() != True:
        qcolor = QColor(self.line_color)
        line_width = self.line_width
        pen = QPen(qcolor)
        pen.setWidth(line_width)
    else:
        qcolor = QColor(self.line_select_color)
        line_width = self.line_select_width
        pen = QPen(qcolor)
        pen.setWidth(line_width)

    p = context.renderContext().painter()
    p.setPen(pen)
    p.drawPolyline(line)

  def clone(self):
    try:
        return CustomLineSymbolLayer(self.line_width, self.line_color,self.line_select_width, self.line_select_color )
    except:
        raise
        #eturn None

class CustomLineSymbolLayerWidget(QgsSymbolLayerV2Widget):
  def __init__(self, parent=None):
    QgsSymbolLayerV2Widget.__init__(self, parent)

    self.layer = None

    # setup a simple UI
    self.label = QLabel("Width:")
    self.spinWidth = QDoubleSpinBox()
    self.hbox = QVBoxLayout()
    self.hbox.addWidget(self.label)
    self.hbox.addWidget(self.spinWidth)

    self.btn1 = QgsColorButtonV2("Color")
    self.btn1.setColor(QColor(0,0,0))
    self.hbox.addWidget(self.btn1)

    #self.hbox2 = QVBoxLayout()
    self.label2 = QLabel("Selection Width:")
    self.select_spinWidth = QDoubleSpinBox()

    self.hbox.addWidget(self.label2)
    self.hbox.addWidget(self.select_spinWidth)

    self.btn2 = QgsColorButtonV2("Selection Color")
    self.btn2.setColor(QColor(0,0,0))
    self.hbox.addWidget(self.btn2)

    self.setLayout(self.hbox)

    self.connect(self.spinWidth, SIGNAL("valueChanged(double)"), self.widthChanged)
    self.connect(self.select_spinWidth, SIGNAL("valueChanged(double)"), self.select_widthChanged)
    self.connect(self.btn1, SIGNAL("clicked()"), self.setLineColor)
    self.connect(self.btn2, SIGNAL("clicked()"), self.setLineSelectionColor)
    self.emit(SIGNAL("changed()"))

  def setSymbolLayer(self, layer):
    if layer == None:
        return

    if layer.layerType() != "AHDCustomLine":
      return

    self.layer = layer
    self.spinWidth.setValue(layer.line_width)
    self.btn1.setColor(QColor(layer.line_color))
    self.select_spinWidth.setValue(layer.line_select_width)
    self.btn2.setColor(QColor(layer.line_select_color))

  def symbolLayer(self):
    return self.layer

  def widthChanged(self, value):
    self.layer.line_width = value
    self.emit(SIGNAL("changed()"))

  def select_widthChanged(self, value):
    self.layer.line_select_width = value
    self.emit(SIGNAL("changed()"))

  def setLineColor(self):
    color = QColorDialog.getColor( QColor(self.layer.line_color), self)
    if not color.isValid(): return
    self.btn1.setColor(color)
    self.line_color = color
    self.layer.line_color = color
    self.emit(SIGNAL("changed()"))

  def setLineSelectionColor(self):
    color = QColorDialog.getColor( QColor(self.layer.line_select_color), self)
    if not color.isValid(): return
    self.btn2.setColor(color)
    self.line_select_color = color
    self.layer.line_select_color = self.line_select_color
    self.emit(SIGNAL("changed()"))


class CustomLineSymbolLayerMetadata(QgsSymbolLayerV2AbstractMetadata):

  def __init__(self):
    QgsSymbolLayerV2AbstractMetadata.__init__(self, "AHDCustomLine", "AHD Custom Flowline", QgsSymbolV2.Line)
    """
       this is where the default values are loaded.  It is a text file that can be edited directly
    """
    self.config = ConfigParser.ConfigParser()
    self.config.read(os.path.join(os.path.dirname(__file__),"config.ini"))

  def createSymbolLayer(self, props):

    default_width = float(self.config.get('ahdflowlinesymbols', 'default_width'))
    default_line_color = self.config.get('ahdflowlinesymbols', 'default_line_color')
    default_select_width = float(self.config.get('ahdflowlinesymbols', 'default_select_width'))
    default_line_select_color = self.config.get('ahdflowlinesymbols', 'default_line_select_color')

    length_props = 0
    try:
        length_props = len(props)
    except:
        pass

    if length_props == 0:
        props = { "NULL" : 1 }

    line_width = float(props[QString("line_width")]) if QString("line_width") in props else default_width

    if QString("line_color") in props:
        line_color = props[QString("line_color")]
    else:
        line_color = default_line_color
    color_array = line_color.split(',')
    line_color = QColor(int(color_array[0]),int(color_array[1]),int(color_array[2]),int(color_array[3]))

    line_select_width = float(props[QString("line_select_width")]) if QString("line_select_width") in props else default_select_width

    if QString("line_select_color") in props:
        mline_color = props[QString("line_select_color")]
    else:
        mline_color = default_line_select_color
    mcolor_array = mline_color.split(',')
    line_select_color = QColor(int(mcolor_array[0]),int(mcolor_array[1]),int(mcolor_array[2]),int(mcolor_array[3]))

    return CustomLineSymbolLayer(line_width, line_color, line_select_width, line_select_color)

  def createSymbolLayerWidget(self):
    try:
        return CustomLineSymbolLayerWidget()
    except:
        return None

QgsSymbolLayerV2Registry.instance().addSymbolLayerType( CustomLineSymbolLayerMetadata() )
