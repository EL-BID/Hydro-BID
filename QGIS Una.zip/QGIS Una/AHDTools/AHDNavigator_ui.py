# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'AHDNavigator_ui.ui'
#
# Created: Tue Jun 09 15:35:07 2015
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_AHDNavigator(object):
    def setupUi(self, AHDNavigator):
        AHDNavigator.setObjectName(_fromUtf8("AHDNavigator"))
        AHDNavigator.setWindowModality(QtCore.Qt.NonModal)
        AHDNavigator.resize(600, 375)
        self.buttonBox = QtGui.QDialogButtonBox(AHDNavigator)
        self.buttonBox.setGeometry(QtCore.QRect(400, 300, 131, 25))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Close|QtGui.QDialogButtonBox.Reset)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.txtFeedback = QtGui.QTextBrowser(AHDNavigator)
        self.txtFeedback.setGeometry(QtCore.QRect(10, 10, 581, 181))
        self.txtFeedback.setObjectName(_fromUtf8("txtFeedback"))
        self.chkActivate = QtGui.QCheckBox(AHDNavigator)
        self.chkActivate.setGeometry(QtCore.QRect(10, 289, 91, 41))
        self.chkActivate.setObjectName(_fromUtf8("chkActivate"))
        self.groupBox = QtGui.QGroupBox(AHDNavigator)
        self.groupBox.setGeometry(QtCore.QRect(130, 280, 160, 75))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.upstream_button = QtGui.QRadioButton(self.groupBox)
        self.upstream_button.setGeometry(QtCore.QRect(10, 20, 82, 18))
        self.upstream_button.setObjectName(_fromUtf8("upstream_button"))
        self.downstream_button = QtGui.QRadioButton(self.groupBox)
        self.downstream_button.setGeometry(QtCore.QRect(10, 45, 102, 18))
        self.downstream_button.setObjectName(_fromUtf8("downstream_button"))
        self.geo_layer_combo_box = QtGui.QComboBox(AHDNavigator)
        self.geo_layer_combo_box.setGeometry(QtCore.QRect(155, 200, 430, 22))
        self.geo_layer_combo_box.setObjectName(_fromUtf8("geo_layer_combo_box"))
        self.label = QtGui.QLabel(AHDNavigator)
        self.label.setGeometry(QtCore.QRect(10, 200, 151, 21))
        self.label.setObjectName(_fromUtf8("label"))
        self.flow_table_combo_box = QtGui.QComboBox(AHDNavigator)
        self.flow_table_combo_box.setGeometry(QtCore.QRect(155, 236, 430, 22))
        self.flow_table_combo_box.setObjectName(_fromUtf8("flow_table_combo_box"))
        self.label_2 = QtGui.QLabel(AHDNavigator)
        self.label_2.setGeometry(QtCore.QRect(11, 236, 151, 21))
        self.label_2.setObjectName(_fromUtf8("label_2"))

        self.retranslateUi(AHDNavigator)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), AHDNavigator.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), AHDNavigator.reject)
        QtCore.QMetaObject.connectSlotsByName(AHDNavigator)

    def retranslateUi(self, AHDNavigator):
        AHDNavigator.setWindowTitle(_translate("AHDNavigator", "RTI Analytical Hydrology Dataset Navigator", None))
        self.chkActivate.setText(_translate("AHDNavigator", "Activate\n"
"(check)", None))
        self.groupBox.setTitle(_translate("AHDNavigator", "Navigate Direction", None))
        self.upstream_button.setText(_translate("AHDNavigator", "Upstream", None))
        self.downstream_button.setText(_translate("AHDNavigator", "Downstream", None))
        self.geo_layer_combo_box.setToolTip(_translate("AHDNavigator", "Select AHD Catchment or Stream Layer", None))
        self.label.setText(_translate("AHDNavigator", "Geometry Layer.........", None))
        self.flow_table_combo_box.setToolTip(_translate("AHDNavigator", "Select AHD Catchment or Stream Layer", None))
        self.label_2.setText(_translate("AHDNavigator", "AHD Flow Table.........", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    AHDNavigator = QtGui.QDialog()
    ui = Ui_AHDNavigator()
    ui.setupUi(AHDNavigator)
    AHDNavigator.show()
    sys.exit(app.exec_())

