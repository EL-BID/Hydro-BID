"""
/***************************************************************************
GWDataPrepBase- this is the base class for the GWDataPrep and the GWDataPrep dialog.
 The AHDTool creates the dialog, and then when the user hits the button for the GWDataPrep it
 initializes the GWDataPrep class and wires up the signals and then shows and raises the dialog

                             -------------------
        begin                : 2016-03-23
        copyright            : (C) 2016 by RTI International for Interamerican Development Bank
        email                : mbruhn@rti.org
        TODO:
        1.Done. Modify interface so that OK button is present and vertical, add new label "<b>Join Catchment Attributes to GW points?</b>" to the left of the OK button 
        2. Done. reproject the polylayer to the same CRS as the point layer
        3. Done. processing.runalg("saga:addPolygonAttributesToPoints",pointLayer, polyLayer, None) to get a path to a temporary shapefile
        4. Done. Load in the shapefile to a layer
        5.export layer to a csv file using snippets of code from liz3   QgisQuickExport.py file in AHD tools
 ***************************************************************************/
"""
import datetime
import ConfigParser
import ctypes
import processing
import csv
import os.path
import locale

from GWprep2_ui import Ui_GWprep
###from AHDNavClass import *
###from ahdUtils import DefaultDict

# Import the PyQt and QGIS libraries.
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *

from PyQt4 import QtCore, QtGui
from qgis import core

# create the GWDataPrep Dialog.  This is called by the AHDTools during the __init__

class GWDataPrepBaseDialog(QtGui.QDialog, Ui_GWprep):

    def __init__(self, AHDTools): # , debug_flag):

        QtGui.QDialog.__init__(self)

        # Set up the user interface from Designer.
        self.ui = Ui_GWprep()
        self.ui.setupUi(self)

        self.debug_flag = False    # False (production) or True (testing)

        self.iface = AHDTools.iface

        self.ui.txtFeedback.append("InitGWDataPrepBaseDialog")
        self.dlg.raise_()

        return

    def __del__(self):
        self.ui = None

    def closeEvent(self, event):
        self.appendTextBrowser("debug", "---- dlg.closeEvent(self) ----")
        #self.emit(SIGNAL('clicked(QAbstractButton *)'))

    def debugFlag(self, setting='NONBOOL'):
        if setting != 'NONBOOL':
            self.debug_flag = bool(setting)
        return self.debug_flag

    def clearTextBrowser(self):
        # in debug mode this just prints a message.  Else it clears the text box
        try:
            if self.debugFlag() == False:
                self.ui.txtFeedback.clear()
            else:
                self.appendTextBrowser("------------- clearTextBrowser() -----------")
        except:
            pass

    """
        this can be called with one or two arguments.  If called with two then the
        first argument is used to decide if the second argument should be printed.
        If the system is set to debug then the second will always be printed. If
        debug is set to False then the second argument will be printed only if the first
        argument is 'force_debug'
        If only one argument is supplied it will be printed only if debug is set to True
    """
    def appendTextBrowser(self, debug_flagger, output=""):
        line_tx = ''
        try:
            ###self.ui.txtFeedback.append(line_tx +  "Got To appendTextBrowser")
            if self.debugFlag() == True:
                now = datetime.datetime.now()
                line_tx = "%02i%02i%02i.%03i: " % (now.hour, now.minute, now.second, now.microsecond/1000)

            if len(output) > 0 and self.debugFlag() == True:
                self.ui.txtFeedback.append(line_tx +  output)
            elif len(output) > 0 and debug_flagger == "force_debug":
                self.ui.txtFeedback.append(line_tx +   output)
            elif len(output) == 0:
                self.ui.txtFeedback.append(line_tx +   debug_flagger)
        except:
            pass

class GWDataPrepBase:


    def __init__(self, dlg, config):

        self.dlg = dlg

        # Save reference to the QGIS interface
        self.iface = self.dlg.iface
        # reference to map canvas
        self.canvas = self.iface.mapCanvas()
        # reference to map tool
        self.saveTool = self.canvas.mapTool()
        # our click tool will emit a QgsPoint on every click
        self.pointEmitter = self.PointEmitter(self.canvas)
        # this is the reference to the AhdNav in the AHDNavClass
        self.AhdNav = None

        self.run()

    def idColName(self, field_tx=''):
##        if hasattr(self,'__idcol_name_tx') == False:
##            self.dlg.appendTextBrowser("debug", "did not have attribute __idcol_name_tx")
##            self.__idcol_name_tx = ''

        if len(field_tx) > 0:
            self.__idcol_name_tx = field_tx

        return str(self.__idcol_name_tx)
    def toColName(self, field_tx=''):
##        if hasattr(self,'__tocol_name_tx') == False:
##            self.__tocol_name_tx = ''

        if len(field_tx) > 0:
            self.__tocol_name_tx = field_tx

        return self.__tocol_name_tx
    def fromColName(self, field_tx=''):
##        if hasattr(self,'__fromcol_name_tx') == False:
##            self.__fromcol_name_tx = ''

        if len(field_tx) > 0:
            self.__fromcol_name_tx = field_tx
        return self.__fromcol_name_tx

    # run method that performs all the real work
    def run(self):

        try:
            self.dlg.show()
            self.dlg.raise_()

            result = self.dlg.exec_()
            
            # See if OK was pressed
            if result == 1:
                self.dlg.show()
                self.dlg.raise_()
                self.dlg.appendTextBrowser("debug", "---- run(self) result == 1 ----")
                #Confirm that it's OK to join the catchments to the points
                #self.dlg.toggle_activate(self,Qt.Unchecked)
                
                if self.gw_point_layer != None and self.isPointLayer(self.gw_point_layer) == True:
                    pointLayer = self.gw_point_layer
                else:
                    self.comboChange()
                    if self.gw_point_layer != None and self.isPointLayer(self.gw_point_layer) == True:
                        pointLayer = self.gw_point_layer
                    else:
                        self.dlg.appendTextBrowser(str(self.gw_point_layer))
                        self.dlg.appendTextBrowser("****The selected point layer is not valid!")
                    #self.dlg.show()
                    #self.dlg.raise_()
                        return 0                    
                polyLayer = self.cat_poly_layer
                thisPolyLayer = polyLayer
                #check to see if "COMID" field already exists in the points attribute table, if so warn user and confirm overwrite OK?
                #TODO
                
                #get output .csv filename & path
		csv_qfd = QFileDialog(self.dlg)
		startPath = "C:\\"
		joinedCSVFilePath = QFileDialog.getSaveFileName(self.dlg, 'Specify output file name and location', startPath)
		self.dlg.show()
                self.dlg.raise_()
                #joinedCSVFilePath = "C:\\testmcb\\mcbt1"
		print joinedCSVFilePath
		if joinedCSVFilePath == "":
		   print "No output file chosen"
		   #ToDO ...break
		outPath = QFileInfo(joinedCSVFilePath).path()
                outBaseName = QFileInfo(joinedCSVFilePath).baseName()
                
                #check to see if the catchments are in the same projection as the points, if not then temprarily reproject catchments to be same projection as points
                pointCRS = pointLayer.crs()
		polyCRS = polyLayer.crs()
		projPolyLayer = outPath + "\\" + "catply_proj.shp"		
                if pointCRS != polyCRS:
                    #processing.runalg('qgis:reprojectlayer',polyLayer, target_CRS, outPolyLayer)
                    processing.runalg('qgis:reprojectlayer',polyLayer, pointCRS, projPolyLayer)
                    thisPolyLayer = projPolyLayer
                    
                #Join the polygon attributes to points
                joinName = outBaseName + ".shp"
                outputPointShapefile = outPath + "\\" + joinName
                fieldsToAdd = "COMID"
                #processing.runalg('saga:addpolygonattributestopoints',pointLayer, polyLayer, None) to get a path to a temporary shapefile                
                processing.runalg('saga:addpolygonattributestopoints', pointLayer, thisPolyLayer, fieldsToAdd, outputPointShapefile)
                
                ##Load in the shapefile to a layer
                #option 1: load into layer and map registry
                #joinedlayer = self.iface.addVectorLayer(outputPointShapefile, outBaseName+ "_Joined", "ogr")
                
                #option 2: just load layer, but not into registry so easier to delete.
                joinedlayer = QgsVectorLayer(outputPointShapefile, outBaseName+ "_Joined", "ogr")
                
                #confirm loading to layer was OK
                if not joinedlayer.isValid():
                    self.dlg.appendTextBrowser("********** Joined layer not valid!")
                    return 0
                
                #Export layer to a csv file using snippets of code from liz3   QgisQuickExport.py file in AHD tools
                #Get output file path & name (done above)
                csvFileName = outPath + "\\" + outBaseName + ".csv"
                
                ####Create empty output .csv file
                
                #Get field names & write to .csv file
                #Open layer for reading records
                #data, nb = self.getLayerData(joinedlayer)
                msg, status = self.exportLayerToCsv(joinedlayer, csvFileName)
                #For each record
                #    read the record values
                #    write the values to the csv file separated by commas
                #close the layer & csv file.               
                
                ###remove temp shapefiles
	           #from qgis.core import QgsVectorFileWrite
	        #remove temp projected catchment polygons
	        if os.path.isfile(projPolyLayer): 
                    QgsVectorFileWriter.deleteShapeFile(projPolyLayer)
                #remove joined pt shapefile
                #if os.path.isfile(outputPointShapefile): 
                #    QgsVectorFileWriter.deleteShapeFile(outputPointShapefile)
                
        except:
            raise
        ### this is reached when the window is closed using the window close widget in the upper right corner, or after the Close button is pressed ###
        self.closeDialog()
        return 1
        
    #------------------------    
    def exportLayerToCsv(self, layer, outcsvfile):
            '''
            Exports the layer to CSV
            '''
            QApplication.setOverrideCursor(Qt.WaitCursor)
    
            # Get layer data
            data, nb = self.getLayerData(layer)
    
            # Export data to CSV
            
            try:
                with open(outcsvfile, 'wb') as csvfile:
                    writer = csv.writer(
                        csvfile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL                       
                    )
                    writer.writerows(data)
                msg = QApplication.translate("quickExport", "The layer has been successfully exported.")
                status = 'info'
                self.dlg.appendTextBrowser("The .csv file has been successfully exported.")
            except OSError, e:
                msg = QApplication.translate("quickExport", "An error occured during export to .csv file" + str(e.error))
                status = 'critical'
                self.dlg.appendTextBrowser("**** An error occured during export to .csv file ****." + str(e.error))
            finally:
                QApplication.restoreOverrideCursor()
    
            return msg, status
    #-----------------------------------------------
    def displayAttributeValue(self, value):
            '''
            Convert QGIS attribute data into readable values
            '''
            # QGIS version
            isQgis2 = True #self.QgisVersion > 10900
    
            # Get locale date representation
            locale.setlocale(locale.LC_TIME,'')
            if hasattr(locale, 'nl_langinfo'):
                date_format = locale.nl_langinfo(locale.D_FMT)
                datetime_format = locale.nl_langinfo(locale.D_T_FMT)
            else:
                date_format = "%x"
                datetime_format = "%x %X"
    
            # Convert value depending of type
            if hasattr(value, 'toPyDate'):
                output = value.toPyDate().strftime(date_format)
            elif hasattr(value, 'toPyDateTime'):
                output = value.toPyDateTime().strftime(datetime_format)
            else:
                output = u"%s" % value if isQgis2 else u"%s" % value.toString()
    
            return output
    #-----------------------------------------------
    def getLayerData(self, layer):
            #Get fields and data from a vector layer
            data = []
    
            # Get layer fields names
            fields = layer.pendingFields()  
            self.dlg.appendTextBrowser("debug", "csv fields: " + str(fields[0].name()))
	    fieldNames = [
		field.name() for i, field in enumerate(fields)		
		#if layer.editType(i) != QgsVectorLayer.Hidden
		#or self.exportHiddenAttributes
	    ]
            data.append(fieldNames)
                       
            # Get selected features or all features
            if layer.selectedFeatureCount():
                nb = layer.selectedFeatureCount()
            else:
                nb = layer.featureCount()
            self.dlg.appendTextBrowser("debug", "nb: " + str(nb))
            
            # Get layer fields data        
            if layer.selectedFeatureCount():
                features = layer.selectedFeatures()
            else:
                features = layer.getFeatures()
            for feat in features:
                # Get attribute data
                values = [
                    self.displayAttributeValue(a) for i, a in enumerate(feat.attributes())
                    #if layer.editType(i) != QgsVectorLayer.Hidden
                    #or self.exportHiddenAttributes
                ]
                data.append(values)                
            return data, nb    
    #---------------------------------------------------------------    
    # this is called from the end of run() and also when the user hits the 'Close' button on the menu
    def closeDialog(self):
        try:
            self.dlg.appendTextBrowser("debug", "--------- closeDialog(self) -----------")
            self.dlg.ui.chkActivate.blockSignals(True)
            self.dlg.ui.chkActivate.setCheckState(Qt.Unchecked)
            ### cursor being set to whatever it used to be ###
            self.canvas.setMapTool(self.saveTool)
            ### cursor being set ###
            QApplication.restoreOverrideCursor()
            self.dlg.ui.chkActivate.blockSignals(False)
            self.dlg.clearTextBrowser()
            self.dlg.ui.AllRecs_button.setChecked(1)
        except:
            pass

    def unload(self):
        self.dlg.raise_()
        self.dlg.appendTextBrowser("debug", "---- unload(self) ----")

    def handleLayerVisibilityChange(self):
        self.dlg.raise_()
        self.dlg.appendTextBrowser("debug", "change of visibility")


    def handleCurrentLayerChanged(self, layer):

        try:
            if layer != None:
                #self.dlg.appendTextBrowser("debug", "layer_id==" + layer.id())
                # now check if anything changed - like layers became invisble
                point_layers = self.setPointLayers(self.dlg.ui.point_layer_combo_box)
                if len(point_layers) == 0:
                    uncheck_bol = True

                poly_layers = self.setPolyLayers(self.dlg.ui.poly_layer_combo_box)
                if len(poly_layers) == 0:
                    uncheck_bol = True
            self.dlg.raise_()
        except:
            self.dlg.appendTextBrowser("handleCurrentLayerChanged(layer_id) exception")
            self.dlg.raise_()
            raise
        pass

    # this is called whenever the selected layer changes
    def handleLayerRemove(self, layer_id):
        try:
            if QgsMapLayerRegistry== None:
                return

            layer = None
            poly_layers = []
            point_layers = []
            allLayers = []

            for myLayerId, myLayer in QgsMapLayerRegistry.instance().mapLayers().iteritems():

                if layer_id == myLayerId:
                    layer = myLayer
                    break
                else:
                    allLayers.append(myLayer)

            if layer == None:
                self.dlg.appendTextBrowser("couldnt find layer to remove for layer_id==" + layer_id)
                raise

            uncheck_bol = False
            if layer != None and self.isPolyLayer(layer) == True:
                # unset the AHDNav if the layer is being removed
                ###if self.AhdNav != None and self.AhdNav.ahdFlowTableLayer() == layer:
                ###    self.AhdNav = None
                ###    uncheck_bol = True

                poly_layers = self.setPolyLayers(self.dlg.ui.poly_layer_combo_box, layer_id)
                layer = None

                if len(poly_layers) == 0:
                    uncheck_bol = True

            if layer != None and self.isPointLayer(layer) == True:

                if self.gw_point_layer != None and self.gw_point_layer == layer:
                    self.gw_point_layer = None

                point_layers = self.setPointLayers(self.dlg.ui.point_layer_combo_box, layer_id)
                layer = None
                if len(point_layers) == 0:
                    uncheck_bol = True

            if uncheck_bol == True:
                self.dlg.ui.chkActivate.blockSignals(True)
                self.dlg.ui.chkActivate.setCheckState(Qt.Unchecked)
                ### cursor being set to whatever it used to be ###
                self.canvas.setMapTool(self.saveTool)
                self.dlg.ui.chkActivate.blockSignals(False)
            layer = None

            # now if there are no more layers, clear the window because they might have unloaded the project
            if len(allLayers) == 0:
                self.allLayersGone()

            self.dlg.raise_()
        except:
            # don't make the connection if you are on something like google maps
            #testing = 1
            self.dlg.appendTextBrowser("in except block in handleLayerRemove for layer_id==" + layer_id)
            raise

    def allLayersGone(self):
        self.dlg.clearTextBrowser()

        # this is the AHD Navigation object.
        self.AhdNav = None

    # this is called when a layer is added
    def handleLayerAdd(self, layer):
        try:
            flow_tables = []
            geo_layers = []
            self.dlg.ui.poly_layer_combo_box.blockSignals(True)
            self.dlg.ui.point_layer_combo_box.blockSignals(True)
            if self.isPolyLayer(layer) == True:
                poly_layers = self.setPolyLayers(self.dlg.ui.poly_layer_combo_box)
            if self.isPointLayer(layer) == True:
                point_layers = self.setPointLayers(self.dlg.ui.point_layer_combo_box)
            self.dlg.ui.poly_layer_combo_box.blockSignals(False)
            self.dlg.ui.point_layer_combo_box.blockSignals(False)

            self.dlg.raise_()
        except:
            raise

    def handleMouseDown(self, point, button, modifiers):
        self.dlg.raise_()

    def toggle_activate(self,state):

         # get the current mapTool
         mapTool_tx = str(self.canvas.mapTool() )
         if mapTool_tx.find('PointEmitter') == -1:
            self.saveTool = self.canvas.mapTool()

         self.dlg.appendTextBrowser("debug", self.idColName() + "; " + self.fromColName()+ "; " + self.toColName() )

         ###self.dlg.appendTextBrowser("debug", "str(self.canvas.mapTool())==" + str(self.canvas.mapTool()))
         self.dlg.ui.chkActivate.blockSignals(True)

         if len(self.getGeoLayers()) == 0:
                QMessageBox.information( self.iface.mainWindow(),"Info", "You need to add a flowline or catchment layer to the map navigate" )
                self.dlg.ui.chkActivate.setCheckState(Qt.Unchecked)
                ### cursor being set to whatever it used to be ###
                self.canvas.setMapTool(self.saveTool)
                self.dlg.raise_()
                self.dlg.ui.chkActivate.blockSignals(False)
                return
         else:
            if self.gw_point_layer != self.point_layer_ComboBoxCurrent():
                """
                This is one of two places where the spatial index on the geometry layer is created
                """
                self.gw_point_layer = self.point_layer_ComboBoxCurrent()
                self.gw_point_spatial_index = self.__createIndex(self.gw_point_layer)


         if len(self.getPolyLayers()) == 0:
                QMessageBox.information( self.iface.mainWindow(),"Info", "You need to add at least one AHDFlow table in order to navigate" )
                self.dlg.ui.chkActivate.setCheckState(Qt.Unchecked)
                ### cursor being set to whatever it used to be ###
                self.canvas.setMapTool(self.saveTool)
                self.dlg.raise_()
                self.dlg.ui.chkActivate.blockSignals(False)
                return
         else:
            self.cat_polys_layer = self.poly_layer_ComboBoxCurrent()


         if (state==Qt.Checked):
            self.dlg.appendTextBrowser("debug", "state == Qt.Checked")
            # activate the tool if conditions are right

            # read in the AhdNav if it isn't already loaded
            if self.AhdNav == None or self.AhdNav.ahdFlowTableLayer() != self.ahd_flow_table_layer:

                self.AhdNav = None
                ### cursor being set ###
                QApplication.setOverrideCursor( QCursor( Qt.BusyCursor ) )

                """
                     This is the only place where the AHD Navigator class gets populated
                """
                self.AhdNav = AHDNav( self.ahd_flow_table_layer, self.idColName(), self.fromColName(), self.toColName() )
                if self.AhdNav.ERROR == None:

                    self.dlg.appendTextBrowser("debug", "A self.ahd_flow_table_layer=" + self.ahd_flow_table_layer.name())
                    self.dlg.appendTextBrowser("debug", "A AHDInstanceNumber=" + str(self.AhdNav.AHDInstanceNumber))

                    if len(self.AhdNav.MESSAGE):
                        self.dlg.appendTextBrowser("debug", "AhdNav.MESSAGE=" + self.AhdNav.MESSAGE)

            ### cursor being set ###
            QApplication.restoreOverrideCursor()
            uncheck_bol = False
            if len(self.AhdNav.ERROR):
                QMessageBox.information( self.iface.mainWindow(),"Info", "Error Loading AHD Navigation. AhdNav.ERROR=" + self.AhdNav.ERROR )
                uncheck_bol = True

            else:
                ### cursor being set to point emitter ###
                self.canvas.setMapTool(self.pointEmitter)

            if uncheck_bol == True:
                self.dlg.ui.chkActivate.setCheckState(Qt.Unchecked)
                ### cursor being set to whatever it used to be ###
                self.canvas.setMapTool(self.saveTool)

         else:
             self.dlg.appendTextBrowser("debug", "state == Qt.Unchecked")
             # de-activate the tool
             ### cursor being set to whatever it used to be ###
             self.canvas.setMapTool(self.saveTool)

         self.dlg.ui.chkActivate.blockSignals(False)
         self.dlg.raise_()

    def radio_AllRecs(self):
        #self.dlg.appendTextBrowser("debug", "direction == Upstream")
        self.navigation_direction = "upstream"

    def radio_OnlyMatchRecs(self):
        #self.dlg.appendTextBrowser("debug", "direction == Downstream")
        self.navigation_direction = "downstream"

    # Source code from Carson  (ftools_utils.py)
    def __createIndex(self, layer):
        provider = layer.dataProvider()
        self.iface.mainWindow().statusBar().showMessage("Creating Spatial Index on " + layer.name())
        feat = core.QgsFeature()
        index = core.QgsSpatialIndex()
        ##provider.rewind()
        for feat in provider.getFeatures():
        #while provider.nextFeature( feat ):
            index.insertFeature( feat )
        self.iface.mainWindow().statusBar().showMessage("Spatial Index created for "  + layer.name())
        return index

    def comboChange(self):
        uncheck_bol = False

        if len(self.getPointLayers()) == 0:
            self.gw_point_layer = None
            uncheck_bol = True
        else:
            self.gw_point_layer = self.point_layer_ComboBoxCurrent()
            """
                This is one of two places where the spatial index on the geometry layer is create
            """
            self.gw_point_spatial_index = self.__createIndex(self.gw_point_layer)

        if len(self.getPolyLayers()) == 0:
            self.cat_poly_layer = None
            ###self.AhdNav = None
        else:
            self.cat_poly_layer = self.poly_layer_ComboBoxCurrent()
            ###if self.AhdNav != None and self.AhdNav.ahdFlowTableLayer() != self.ahd_flow_table_layer:
            ###    self.dlg.appendTextBrowser("debug", "comboChange(self) unsetting self.AhdNav")
            ###    self.AhdNav = None

        try:
            self.dlg.appendTextBrowser("debug", "self.gw_point_layer.name() =" + self.gw_point_layer.name())
        except:
            pass
        try:
            self.dlg.appendTextBrowser("debug", "self.cat_poly_layer.name() =" + self.cat_poly_layer.name())
        except:
            pass

    ###    if uncheck_bol == True or self.AhdNav == None:
    ###       self.dlg.ui.chkActivate.setCheckState(Qt.Unchecked)

    def uiButtonBox_clicked(self, button):
        role = self.dlg.ui.buttonBox.buttonRole(button)
        #""" this is called by the Reset button """
        if role == QtGui.QDialogButtonBox.ResetRole:
            self.dlg.appendTextBrowser("debug", "--------- QtGui.QDialogbuttonBox.Reset -----------")
            ### cursor being set ###
            QApplication.restoreOverrideCursor()
            if self.gw_point_layer != None:
                # unselect all features
                self.gw_point_layer.setSelectedFeatures([])
            """if self.AhdNav != None:
                self.AhdNav.ahdFlowTableLayer().setSelectedFeatures([])
                # connect to click signal
                self.dlg.clearTextBrowser()
                if self.dlg.ui.chkActivate.isChecked() == True:
                    ### cursor being set by pointEmitter ###
                    self.canvas.setMapTool(self.pointEmitter)
            elif self.AhdNav == None:
                self.dlg.clearTextBrowser()
            else:
                pass
            """
        #"" this is called by the Close button """
        elif role == QtGui.QDialogButtonBox.RejectRole:
            self.dlg.appendTextBrowser("debug", "--------- QtGui.QDialogbuttonBox.RejectRole -----------")
            # after this the dialog returns in the run() function, and then closeDialog is called.


    #DONT NEED selectFeature
    def selectFeature(self, point, button, modifiers): # reset selection list on each new selection
        self.dlg.appendTextBrowser("debug", "selectFeature called")
        # this is 'COMID' for AHD and NHD.
        idcol = self.idColName()

        self.selectList = []

        nav_comids = DefaultDict( dict )

        self.ahd_geo_layer = self.geo_layer_ComboBoxCurrent()
        if self.ahd_geo_layer == None:
            QMessageBox.information( self.iface.mainWindow(),"Info", "No layer currently selected in TOC" )
            return

        geo_data_provider = self.ahd_geo_layer.dataProvider()
        if geo_data_provider == None:
            QMessageBox.information( self.iface.mainWindow(),"Info", "ERROR: geo_data_provider==None" )
            return

        feat = QgsFeature()

        self.previous_selection = set(self.ahd_geo_layer.selectedFeaturesIds())

        # this is the features on the AHDFlow table selected earlier
        self.previous_AHDFlow_navigated = set(self.AhdNav.ahdFlowTableLayer().selectedFeaturesIds())

        allAttrs = geo_data_provider.attributeIndexes()

        # get the feature which has the closest bounding box using the spatial index
        # get the point coordinates in the layer's CRS
        point = self.canvas.mapRenderer().mapToLayerCoordinates(self.ahd_geo_layer, point)
        ##myx = str(point.x)
        ##myy = str(point.y)
        ##self.dlg.appendTextBrowser("debug", "selectFeature X:" + myx + " Y:"+ myy)

        nearest = self.ahd_geo_spatial_index.nearestNeighbor( point, 1 )
        featureId = nearest[0] if len(nearest) > 0 else None

        closestFeature = QgsFeature()



        if featureId == None:  ##featureAtId(featureId, closestFeature, True, False) == False:
            closestFeature = None
        else:
            closestRequest=QgsFeatureRequest()
            closestRequest.setFilterFid(featureId)
            closestFeature = self.ahd_geo_layer.getFeatures(closestRequest).next()
        # need to figure out how far it is, and set it to None if it exceeds a preset distance.  Right now it can be far away.

        # this still needs to get fixed.  The closest feature might not actually be the point clicked and this is suppposed to test but doesn't work yet
		# if polygon, make a futher test
        if self.ahd_geo_layer.geometryType() != QGis.Point and closestFeature != None:

            # find the furthest bounding box borders
            rect = closestFeature.geometry().boundingBox()

            dist_pX_rXmax = abs( point.x() - rect.xMaximum() )
            dist_pX_rXmin = abs( point.x() - rect.xMinimum() )
            if dist_pX_rXmax > dist_pX_rXmin:
                width = dist_pX_rXmax
            else:
                width = dist_pX_rXmin

            dist_pY_rYmax = abs( point.y() - rect.yMaximum() )
            dist_pY_rYmin = abs( point.y() - rect.yMinimum() )
            if dist_pY_rYmax > dist_pY_rYmin:
                height = dist_pY_rYmax
            else:
                height = dist_pY_rYmin

            # create the search rectangle
            rect = QgsRectangle()
            rect.setXMinimum( point.x() - width )
            rect.setXMaximum( point.x() + width )
            rect.setYMinimum( point.y() - height )
            rect.setYMaximum( point.y() + height )

			# retrieve all geometries into the search rectangle
            srchRectRequest=QgsFeatureRequest()
            srchRectRequest.setFilterRect(rect)
            #self.ahd_geo_layer.select([], rect, True, True)
            self.ahd_geo_layer.getFeatures(srchRectRequest)

            # find the nearest feature
            """ this is where the minimum distance is set. beyond this distance it doesn't count """
            minDist = -1
            featureId = None
            point = QgsGeometry.fromPoint(point)

            ##f = QgsFeature()
            for f in self.ahd_geo_layer.getFeatures():
            ##while self.ahd_geo_layer.nextFeature(f):
            	geom = f.geometry()
            	distance = geom.distance(point)
            	if minDist < 0 or distance < minDist:
            		minDist = distance
            		featureId = f.id()

            ##self.dlg.appendTextBrowser("debug", "Distance to closest feature == %.4f" % distance)

            # get the closest feature
            closestFeature = QgsFeature()
            if featureId == None:  ##featureAtId(featureId, closestFeature, True, False) == False:
                closestFeature = None
            else:
                 closestRequest=QgsFeatureRequest()
                 closestRequest.setFilterFid(featureId)
                 closestFeature = self.ahd_geo_layer.getFeatures(closestRequest).next()

            ##if featureId == None or self.ahd_geo_layer.featureAtId(featureId, closestFeature, True, False) == False:
            ##	closestFeature = None

        if closestFeature != None:
            # if the feat geom returned from the selection intersects our point then put it in a list
            self.selectList.append(closestFeature.id())

        # there are no selected features.  So return
        if len(self.selectList) == 0:
            return

        self.iface.mainWindow().statusBar().showMessage("Navigation Started")


        # make the actual selection of the point selected with the mouse
        self.ahd_geo_layer.setSelectedFeatures(self.selectList)

        # find the index of the 'COMID' column, branch if has one or not
        comid_col_nu = geo_data_provider.fieldNameIndex(idcol)
        area_col_nu =geo_data_provider.fieldNameIndex('areasqkm')

        # We can navigate only if we have a 'COMID' column in the selected layer
        if comid_col_nu == -1:
            QMessageBox.information( self.iface.mainWindow(),"Info", "The selected layer doesn't have a " + idcol + " field.  Select a catchment or flowline layer in TOC" )
            return

        ### cursor being set ###
        QApplication.setOverrideCursor( QCursor( Qt.BusyCursor ) )
        # get our selected feature from the provider, but we have to pass in an empty feature and the column index we want
        feat = QgsFeature()
        ##allAttrs = geo_data_provider.attributeIndexes()
        myRequest = QgsFeatureRequest()
        myRequest.setFilterFid(self.selectList[0])
        myRequest.setSubsetOfAttributes(allAttrs)
        feat = geo_data_provider.getFeatures(myRequest).next()
        if feat != None:
        ##if geo_data_provider.featureAtId(self.selectList[0], feat, True, allAttrs):

            # get the feature attributeMap
            ##attMap = feat.attributeMap()
            ##comid = str(attMap[comid_col_nu]) #.toString() )
            comid = str(feat[comid_col_nu])
            whereami = ""
            self.dlg.clearTextBrowser()
            self.dlg.appendTextBrowser("debug", "AHD Layer"+whereami+"=  " + self.ahd_geo_layer.name())
            self.dlg.appendTextBrowser("debug", "FlowLayer"+whereami+"=  " + self.AhdNav.ahdFlowTableLayer().name())

            feature_type_tx = "catchment" if area_col_nu != -1 else "stream segment"
            self.dlg.appendTextBrowser("start " + feature_type_tx + " " + idcol + "==" + str(int(float(comid))))

            direction_tx = self.navigation_direction

            """
                This is where the AHD Navigation takes place.  Given a single COMID, navigate and return a dict of navigated FROMCOMID/TOCOMID
            """
            self.iface.mainWindow().statusBar().showMessage("Navigating on " + self.ahd_geo_layer.name())
            #bug in int() necessitates converting a quoted comid value to float first before converting to an integer
            intcomid = int(float(comid))
            nav_comids = self.AhdNav.navigate(intcomid, direction_tx)

            if len(self.AhdNav.MESSAGE):
                self.dlg.appendTextBrowser("debug", self.AhdNav.MESSAGE)

            if len(nav_comids) > 0:
                self.AhdNav.COMID_NAVIGATED = comid
            else:
                self.AhdNav.COMID_NAVIGATED = 0

            # Add the initial COMID
            intcomid = int(float(comid))
            nav_comids[intcomid] = 1

            self.comid_count_nu = len(nav_comids)
            self.iface.mainWindow().statusBar().showMessage("Navigation complete on " + str(self.comid_count_nu) + " features.")

        ##feat = QgsFeature()
        ##geo_data_provider.rewind()
        ##allAttrs = geo_data_provider.attributeIndexes()
        ##geo_data_provider.select(allAttrs)

        """
            This is the most time consuming part of the process, where all the features in the geometry layer get searched by comid
        """
        selection = []
        for feat in geo_data_provider.getFeatures():
        ##while (geo_data_provider.nextFeature(feat)):
            ##attMap=feat.attributeMap()
            ##comid = int(attMap[comid_col_nu][ 0 ])   # .toInt()
            comid = int(feat[comid_col_nu])
            if  nav_comids.has_key(comid) == True:
                selection.append(feat.id())

                del(nav_comids[comid])
            if len(nav_comids) == 0:
                break

        # data_ref is an array returning QGisFeatures
        data_ref = self.AhdNav.AHDFlow_navigated()

        navigation_selection = []
        for tocomid in data_ref.keys():
            for fromcomid in data_ref[tocomid].keys():
                navigation_selection.append(data_ref[tocomid][fromcomid])

        """
            this is set arithmetic deciding if the previous set is added together, or the new set is subtracted
        """
        # select the feature according to the pressed key modifiers
        geo_selection = set(selection)
        flow_selection = set(navigation_selection)

        if modifiers & Qt.ControlModifier: # add new selection to existing selection
            geo_selection = geo_selection.union(self.previous_selection)
            flow_selection = flow_selection.union(self.previous_AHDFlow_navigated)

        elif modifiers & Qt.ShiftModifier: # subtract new selection from existing selection
            geo_selection = self.previous_selection.difference(geo_selection)
            flow_selection = self.previous_AHDFlow_navigated.difference(flow_selection)

        """
            This is where the geometry layer and the AHDFlow table layer rows are selected
            this is where the user interface is updated and the selection made
        """
        geo_selection_list = list(geo_selection)
        flow_selection_list = list(flow_selection)

        ##self.ahd_geo_layer.setSelectedFeatures(geo_selection)
        self.ahd_geo_layer.setSelectedFeatures(geo_selection_list)
        self.AhdNav.ahdFlowTableLayer().setSelectedFeatures(flow_selection_list)

        """
            This is a somewhat generalized data accumulator.
            There is an array that can contain n-number of columss, the type of computation to perform,
            and the string to use to print the results.
        """
        fields = [
                  ['LENGTHKM','sum', 'total length (km) == %2.f'],
                  ['areasqkm','sum',  'total area (sq km) ==  %.2f'],
                  ['MAXELEVRAW','max', 'max elevation (meters) ==  %d'],
                  ['MINELEVRAW','min', 'min elevation (meters) ==  %d'],
                  ['SLOPE', 'mean', 'average slope ==  %.5f'],
                  ['GRID_COUNT', 'sum', 'total GRID_COUNT (nu) == %d'],
                  ['ACRES', 'sum', 'total ACRES == %d']
                  ]

        attindex = DefaultDict(dict)
        for field in fields:
            field_nm = field[0]
            if geo_data_provider.fieldNameIndex(field_nm) != -1:
                attindex[field_nm] = {}
                attindex[field_nm]['col_nu'] = geo_data_provider.fieldNameIndex(field_nm)
                attindex[field_nm]['values']  = []
                attindex[field_nm]['function'] = field[1]
                attindex[field_nm]['print_string'] = field[2]

        # now compute the statistics for the selected features

        all_nav_comids = DefaultDict( dict )
        ##geo_data_provider.rewind()

        for feat in self.ahd_geo_layer.selectedFeatures():

            ##attMap=feat.attributeMap()

            # save a list of all the COMIDs in the selected feature set ###
            ##all_nav_comids[attMap[comid_col_nu][ 0 ]] = 1     #.toInt()
            all_nav_comids[int(feat[comid_col_nu])][0] = 1
            """ build up all the values in the 'values' list in the attIndex dictionary """
            for field_nm in attindex.keys():
                ##attindex[field_nm]['values'].append(attMap[attindex[field_nm]['col_nu']].toDouble()[0])
                ##ctypes.windll.user32.MessageBoxA(0, "Field_nm:"+ str(feat[field_nm]), "MCB Debugging", 0)
                attindex[field_nm]['values'].append(float(feat[field_nm]))
        feature_type_tx = "catchments" if attindex.has_key('areasqkm') else "stream segments"

        self.dlg.appendTextBrowser("count of %s = %d" % (feature_type_tx, len(all_nav_comids)))
        for field_nm in attindex.keys():
            v = 0
            try:
                if attindex[field_nm]['function'] == 'sum':
                    v = sum(attindex[field_nm]['values'])
                elif attindex[field_nm]['function'] == 'max':
                    v = max(attindex[field_nm]['values'])
                elif attindex[field_nm]['function']  == 'min':
                    v = min(attindex[field_nm]['values'])
                elif attindex[field_nm]['function'] == 'mean':
                    v = sum(attindex[field_nm]['values'])/len(attindex[field_nm]['values'])
                else:
                    raise
            except:
                v = -99
                mtext = str(attindex[field_nm]['values'])

            self.dlg.appendTextBrowser(attindex[field_nm]['print_string'] % v)

        """
             save the results in the config_parser for the IWRM
        """
        if hasattr(self, 'config') == True:
            section_nm = 'ahd_navigation_results'
            try:
                config_parser = self.config
                try:
                    config_parser.remove_section(section_nm)
                except config_parser.NoSectionError:
                    pass
                except:
                    raise

                config_parser.add_section(section_nm)
                config_parser.set(section_nm, "AHD Geometry Layer", self.ahd_geo_layer.name())
                config_parser.set(section_nm, "AHD Flow Table Layer", self.AhdNav.ahdFlowTableLayer().name())
                config_parser.set(section_nm, 'initial ' + idcol, str(self.AhdNav.COMID_NAVIGATED))
                config_parser.set(section_nm, 'feature_type', feature_type_tx)
                config_parser.set(section_nm, 'feature_count', len(all_nav_comids))

                for field_nm in attindex.keys():
                    v = 0
                    try:
                        if attindex[field_nm]['function'] == 'sum':
                            v = sum(attindex[field_nm]['values'])
                        elif attindex[field_nm]['function'] == 'max':
                            v = max(attindex[field_nm]['values'])
                        elif attindex[field_nm]['function']  == 'min':
                            v = min(attindex[field_nm]['values'])
                        elif attindex[field_nm]['function'] == 'mean':
                            v = sum(attindex[field_nm]['values'])/len(attindex[field_nm]['values'])
                        else:
                            raise
                            mtext = str(attindex[field_nm]['values'])
                    except:
                        v = -999

                    mstring = attindex[field_nm]['print_string'] % v
                    (pstring, value_tx) = mstring.split(' == ')
                    config_parser.set(section_nm, pstring, value_tx)

            except:
                raise

        """
            This section handles selecting from AHDFlow for all features in the selected layer.  It needs to be simplified,
            since the majority of features were selected in earlier steps.  This repeats some work.  I think.  -- Jimmy
        """
        if modifiers & Qt.ControlModifier: # add new selection to existing selection
            # now select all the AHD Flow again for all selected features
            comids = set(all_nav_comids.keys())
            ahd_flow_navigated_ref = self.AhdNav.navigate_selected(comids)
            # now make the selection
            navigation_selection = []
            for tocomid in ahd_flow_navigated_ref.keys():
                for fromcomid in ahd_flow_navigated_ref[tocomid].keys():
                    navigation_selection.append(ahd_flow_navigated_ref[tocomid][fromcomid])
            flow_selection = set(navigation_selection)

            """ make the actual selection here """
            flow_selection_list = list(flow_selection)
            self.AhdNav.ahdFlowTableLayer().setSelectedFeatures(flow_selection_list)

        ### cursor being set ###
        QApplication.restoreOverrideCursor()

        self.iface.mainWindow().statusBar().showMessage("Navigation Completed. " + str(self.comid_count_nu) + " features selected on " + self.ahd_geo_layer.name())
        return 1
        
    def point_layer_ComboBoxCurrent(self):
        return QgsMapLayerRegistry.instance().mapLayer(str(self.dlg.ui.point_layer_combo_box.itemData(self.dlg.ui.point_layer_combo_box.currentIndex() )))  #.toString())

   # get the geometry layers that the users can navigate
    def getPointLayers(self, skip_layer_id=""):
        myLayers = []
        legend = self.iface.legendInterface()
        for  myLayer in legend.layers():
            if myLayer.id() !=skip_layer_id and self.isPointLayer(myLayer) == True:  ## and legend.isLayerVisible(myLayer) == True
                myLayers.append(myLayer)
        return myLayers

    # get the geometry layers that the users can navigate
    def setPointLayers(self, combo_box, skip_layer_id=""):
        myLayers = []
        #myLayersNames = []
        combo_box.blockSignals(True)
        current_layer = self.point_layer_ComboBoxCurrent()
        combo_box.clear()
        legend = self.iface.legendInterface()
        i = -1
        for  myLayer in legend.layers():
            if myLayer.id() !=skip_layer_id  and self.isPointLayer(myLayer) == True: ## and legend.isLayerVisible(myLayer) == True
                i = i + 1
                combo_box.addItem(myLayer.name(),myLayer.id())
                if current_layer != None and myLayer.id() == current_layer.id():
                    combo_box.setCurrentIndex(i)
                myLayers.append(myLayer)

        combo_box.blockSignals(False)
        return myLayers

    # get the AHD Flow Table that is the basis for the navigation

    def poly_layer_ComboBoxCurrent(self):  
        return QgsMapLayerRegistry.instance().mapLayer(str(self.dlg.ui.poly_layer_combo_box.itemData(self.dlg.ui.poly_layer_combo_box.currentIndex()))) #.toString())

    def getPolyLayers(self, skip_layer_id=""):
        myPolyLayers = []
        legend = self.iface.legendInterface()
        for  myLayer in legend.layers():
            if myLayer.id() !=skip_layer_id and self.isPolyLayer(myLayer) == True:
                myPolyLayers.append(myLayer)
        return myPolyLayers

    def setPolyLayers(self, combo_box, skip_layer_id=""):
        myPolyLayers = []
        combo_box.blockSignals(True)
        current_layer = self.poly_layer_ComboBoxCurrent()
        combo_box.clear()
        legend = self.iface.legendInterface()
        i = -1
        for  myLayer in legend.layers():
           ### self.ui.txtFeedback.append(str(myLayer.name))  ###MCB

            if myLayer.id() !=skip_layer_id  and self.isPolyLayer(myLayer) == True:
                i = i + 1
                combo_box.addItem(myLayer.name(),myLayer.id())
                if current_layer != None and myLayer.id() == current_layer.id():
                    combo_box.setCurrentIndex(i)
                myPolyLayers.append(myLayer)

        combo_box.blockSignals(False)
        return myPolyLayers

    def isPointLayer(self, layer):

        #idcol = self.idColName()
        # check if the layer is a Point vector layer     (A|N)HDFlowline or (A|N)HDCatchment layer
        # must have point geometry
        if layer == None:
            ##self.dlg.appendTextBrowser("debug", "No Flowline or Catchment Layers: isFlowlineOrCatchment")
            return False

        try:
            if layer.type() != layer.VectorLayer:
                return False

            ##if layer.isUsingRendererV2() != True:
            ###if layer.rendererV2() == None:
            ###    return False

            provider = layer.dataProvider()
            if provider == None:
                return False

            feat = core.QgsFeature()
            feat = provider.getFeatures().next()

            if feat.geometry() == None:
                return False
            if feat.geometry().type() != QGis.Point:
                return False

            self.dlg.appendTextBrowser("debug", "Point Geometry Layers found: isPointLayer")
            return True
        except:
            self.dlg.appendTextBrowser("debug", "---- isPointLayer(layer) exception ----")
            return False

    def isPolyLayer(self, layer):

        # check if the layer is a polygon layer.
        if layer == None:
            return False
        ###ctypes.windll.user32.MessageBoxA(0,str(layer.name)   , "isAHDFlowTable",1)
        try:
            if layer.type() != layer.VectorLayer:
                return False

             ##if layer.isUsingRendererV2() != True:
            ###if layer.rendererV2() == None:
            ###    return False

            provider = layer.dataProvider()
            if provider == None:
                return False

            feat = core.QgsFeature()
            feat = provider.getFeatures().next()
            if feat.geometry() == None:
                return False
            if feat.geometry().type() != QGis.Polygon:
                return False

            self.dlg.appendTextBrowser("debug","Polygon Geometry Layers found: isPolygonLayer")
            return True
        except:
            #self.dlg.appendTextBroswer2("---- isAHDFlowTable(layer) exception ----", debug=True)
            self.dlg.appendTextBrowser("debug", "---- isPolyLayers(layer) exception ----")
            return False

    class PointEmitter(QgsMapToolEmitPoint):

    ##class PointEmitter(QtCore.QObject):
        canvasClickedWithModifiers = QtCore.pyqtSignal(QgsPoint, Qt.MouseButton, Qt.KeyboardModifiers)

        def __init__(self, canvas):
            QgsMapToolEmitPoint.__init__(self, canvas)
            self.canvas = canvas
            ##QtCore.QObject.__init__(self,canvas)


        def canvasPressEvent(self, mouseEvent):
        	#point = self.toMapCoordinates(mouseEvent.pos())
            point = self.toMapCoordinates(mouseEvent.pos())
            ##canvasClickedWithModifiers = QtCore.pyqtSignal(point) ##,mouseEvent.button(), mouseEvent.modifiers())
            self.canvasClickedWithModifiers.emit(point, mouseEvent.button(), mouseEvent.modifiers())
        	#self.emit( SIGNAL( "canvasClickedWithModifiers" ), point, mouseEvent.button(), mouseEvent.modifiers() )

