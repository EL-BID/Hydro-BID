"""
/***************************************************************************
 AHD Navigator - is a subclass of AHD Navigator Base without any changes (I think)

                             -------------------
        begin                : 2012-01-10
        copyright            : (C) 2012 by RTI International for Interamerican Development Bank
        email                : jbisese@rti.org
 ***************************************************************************/
"""

class DefaultDict(dict):
    """Dictionary with a default value for unknown keys."""
    def __init__(self, default):
        self.default = default

    def __getitem__(self, key):
        if not self.has_key(key):
            self[key] = self.default()
        return dict.__getitem__(self, key)