"""
/***************************************************************************
 GWprep.  Handles some groundwater data preparation for ModFlow model.

                             -------------------
        begin                : 2016-03-22
        copyright            : (C) 2016 by RTI International for Interamerican Development Bank
        email                : mbruhn@rti.org
 ***************************************************************************/
"""
from PyQt4.QtCore import *
from PyQt4.QtGui import *

from qgis.core import *
from GWprep2_ui import Ui_GWprep

class GWprepDialog(QDialog, Ui_GWprep):

    def __init__(self, AHDTools):
        QDialog.__init__(self)

        self.setupUi(self)

class GWprep:
    def __init__(self, dlg, config):
        self.dlg = dlg

        self.config = config

        """
        # TODO - populate with GWPrep dialog items instead of About items
        /**** if self.config.has_section('general'):
            version = self.config.get('general', 'version')
            self.dlg.label.setText("Version: " + version)
            contact = self.config.get('general', 'contact')
            self.dlg.label_3.setText("Contact: " + contact)
            link = self.config.get('general', 'URL')
            main_tx = self.dlg.textBrowser.toHtml()
            main_tx.replace('http://www.rti.org', link)
            self.dlg.textBrowser.setText(main_tx)
        ****/
        """
        self.run()

    # run method that performs all the real work
    def run(self):
        try:
            self.dlg.show()
            self.dlg.raise_()

            result = self.dlg.exec_()
        except:
            raise

        ### this is reached when the window is closed using the window close widget in the upper right corner, ###
        ### or after the Close button is pressed ###
        return 1