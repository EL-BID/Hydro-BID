"""
/***************************************************************************
 AHD Navigator - is a subclass of AHD Navigator Base without any changes (I think)

                             -------------------
        begin                : 2012-01-10
        copyright            : (C) 2012 by RTI International for Interamerican Development Bank
        email                : jbisese@rti.org
 ***************************************************************************/
"""

# imports

from qgis.core import *
from PyQt4 import QtCore
from ahdUtils import DefaultDict
import ctypes

class AHDNav(object):

    mAHDFlow_navigated = DefaultDict(dict)

    def __init__(self, table_layer, idcol,fromcol,tocol):
        #
        #ctypes.windll.user32.MessageBoxA(0, "Made it to AHDNav INIT", "MCB Debugging", 0)
        """ these are the default columns for to and from """
        self.toColName(tocol)
        self.fromColName(fromcol)

        self.ERROR = ''
        self.MESSAGE = ''
        self.COMID_NAVIGATED = 0

        self.ahdFlowTableLayer(table_layer)

        # this is a big problem and shouldn't happen
        if self.ahdFlowTableLayer() == None:
            self.ERROR = "Unable to find AHDFlowTableLayer"
            return
        else:
            """ Load the navigation for both upstream and downstream navigation """
            (upstream, downstream) = self.read_ahd_flow_layer(self.ahdFlowTableLayer())
            self.ahdFlowUpstream(upstream)
            self.ahdFlowDownstream(downstream)
            ##ctypes.windll.user32.MessageBoxA(0, "Made it to AHDNav INIT-flow updown", "MCB Debugging", 0)

    def AHDFlow_navigated(self):
        return self.mAHDFlow_navigated
    def AHDFlow_navigatedClear(self):
        self.mAHDFlow_navigated = DefaultDict( dict )

    def iteration_count(self):
        if hasattr(self, "__count_nu") == False:
            self.__count_nu = 0

        self.__count_nu = self.__count_nu + 1
        return self.__count_nu

    def toColName(self, field_tx=''):
        if len(field_tx) > 0:
            self.__tocol_name_tx = field_tx
        return self.__tocol_name_tx
    def fromColName(self, field_tx=''):
        if len(field_tx) > 0:
            self.__fromcol_name_tx = field_tx
        return self.__fromcol_name_tx

    def ahdFlowTableLayer(self, data_ref=None):
        if data_ref != None:
            self.__ahd_flow_table_layer = data_ref
        return self.__ahd_flow_table_layer

    def ahdFlowUpstream(self, data_ref=None):
        if data_ref != None:
            self.__ahd_flow_tofrom = data_ref
        return self.__ahd_flow_tofrom

    def ahdFlowDownstream(self, data_ref=None):
        if data_ref != None:
            self.__ahd_flow_fromto = data_ref
        return self.__ahd_flow_fromto

    def navigate(self,comid, direction):

        nav_comids = DefaultDict( dict )
        feature_ref = DefaultDict( dict )
        self.AHDFlow_iteration_count = 0
        mycomids = { comid: 1}

        """ this is a big deal here.  If you are navigating downstream you use a different array than if you are going upstream """
        data_ref = self.ahdFlowDownstream() if direction == "downstream" else self.ahdFlowUpstream()

        """ the variables tocomid and fromcomid are the correct terms only for upstream navigation.  If you are doing
            downstream navigation they are actually reversed. """
        try:
            while 1 == 1:
                for tocomid in mycomids.keys():
                    if data_ref.has_key(tocomid) == True:
                        for fromcomid in data_ref[tocomid].keys():
                            if fromcomid != 0:
                                mycomids[fromcomid] = 1

                            nav_comids[fromcomid] = 1

                            # keep the feature id for all the AHDFlow features navigated
                            feature_ref[tocomid][fromcomid] = data_ref[tocomid][fromcomid]

                    del mycomids[tocomid]

                """ this keeps track of the number of iterations.  It was useful for debugging, but isn't used anymore. """
                self.iteration_count()

                if len(mycomids.keys()) == 0:
                    break

            self.mAHDFlow_navigated = feature_ref
            return nav_comids
        except:
            self.ERROR = "---------- in except in navigate(self, comid, direction) -------"
            raise

    """ this gets a list of all the rows in the AHDFlow table that are in anyway related to the COMIDs of the selected features """
    def navigate_selected(self, comids):

        ahd_flow_navigated_ref = DefaultDict( dict )

        upstream_data_ref=   self.ahdFlowUpstream()
        downstream_data_ref = self.ahdFlowDownstream()

        try:
            # process all features that are in the selected comids set

            for comid in comids:
                # first do the downstream nav check
                if downstream_data_ref.has_key(comid) == True:
                    for tocomid in downstream_data_ref[comid].keys():
                        ahd_flow_navigated_ref[comid][tocomid] = downstream_data_ref[comid][tocomid]

                try:
                    if downstream_data_ref[0].has_key(comid) != None:
                        ahd_flow_navigated_ref[0][comid] = downstream_data_ref[0][comid]
                except KeyError:
                    pass
                except:
                    raise

                # then do the upstream check
                if upstream_data_ref.has_key(comid) == True:
                    for fromcomid in upstream_data_ref[comid].keys():
                        ahd_flow_navigated_ref[fromcomid][comid] = upstream_data_ref[comid][fromcomid]

            return ahd_flow_navigated_ref
        except:
            self.ERROR =  "---------- in except in navigate_selected(self, comids, upstream_data_ref, downstream_data_ref) -------"
            raise

    """ this reads an AHDFlow table into an upstream and downstream data arrays it returns both arrays """
    def read_ahd_flow_layer(self, table_layer):
        fromcol = self.fromColName()
        tocol = self.toColName()
        ##ctypes.windll.user32.MessageBoxA(0, "Made it to AHDNav read", "MCB Debugging", 0)
        try:
            upstream_data_ref = DefaultDict( dict )
            downstream_data_ref = DefaultDict( dict )

            ### check that it has the FROMCOMID and TOCOMID fields
            provider = table_layer.dataProvider()
            tocomid_col_nu =provider.fieldNameIndex(tocol)
            fromcomid_col_nu =provider.fieldNameIndex(fromcol)
            if tocomid_col_nu == -1:
                raise
            if fromcomid_col_nu == -1:
                raise

            feat = QgsFeature()
            ##allAttrs = provider.attributeIndexes()

            ##provider.select(allAttrs)
            ##while provider.nextFeature(feat):
            for feat in provider.getFeatures():
                ##attMap = feat.attributeMap()
                tocomid = int(feat[str(tocol)])
                fromcomid = int(feat[str(fromcol)])

                # this is the navigator for upstream.  The feature ID is the value

                upstream_data_ref[tocomid][fromcomid] = feat.id()
                # this is the navigator for downstream
                downstream_data_ref[fromcomid][tocomid] = feat.id()

            return (upstream_data_ref , downstream_data_ref)
        except:
            self.ERROR = "---------- in except in read_ahd_flow_layer(self, table_layer) -------"
            raise

